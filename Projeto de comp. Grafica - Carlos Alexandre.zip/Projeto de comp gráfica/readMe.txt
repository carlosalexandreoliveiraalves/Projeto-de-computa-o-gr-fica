Para os movimentos do escorpião:

@@@@ ATENÇÃO: AS IMAGENS DEVEM SER COLOCADAS NO DIRETÓRIO C:// @@@@
@@@@ E O CODEBLOCKS EXECUTADO COMO ADMINISTRADOR @@@@
@@@@ CASO NÃO SEJA FEITO ISSO, LEMBRE-SE DE MUDAR O DIRETÓRIO EM QUE SÃO COLOCADAS AS TEXTURAS @@@@

q, w, e r: Movimentos das patas esq. para baixo
a, s, d, f: Movimentos das patas esq. para cima

g: Abaixar ferrão
T: Levantar ferrão

y, u, i, p: Movimentos das patas dir. para baixo
h, j, k, L: Movimentos das patas dir. para cima

Z: Abre garras
X: Fechar garras

1 - Atacar

2 - Cisne

3 - Duas patas da frente levantadas

4 - Gira o modelo em 22,5°

5 - Andar

6 - Muda para a posição inicial


