#ifndef GL.H
#define GL.H
#include <GL/gl.h>
#include <GL/glut.h>
#endif
void cubo(GLdouble size);
