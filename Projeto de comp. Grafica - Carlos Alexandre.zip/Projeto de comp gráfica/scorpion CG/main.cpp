#include <stdio.h>
#include <stdlib.h>
#include <GL\gl.h>
#include <GL\glut.h>
#include <unistd.h>
#include "cubo.hpp"
#include "soil.h"

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

//#include <gl\glaux.h>
//#include "utilTextura.cpp"

//Aperte Z, X, C, V e B para ativar os métodos da Atividade de Computação Gráfica

/////////   VARIAVEIS GLOBAIS PARA OS ANGULOS////////////
float ang = 0;
float ang2 = 0;
float ang3 = 0;




GLuint      texture[2];
int LoadGLTextures(){ // Load Bitmaps And Convert To Textures
    /* load an image file directly as a new OpenGL texture */
    texture[0] = SOIL_load_OGL_texture ( "C:\\EscorpiaoPernas.png",
        SOIL_LOAD_RGBA, SOIL_CREATE_NEW_ID,SOIL_FLAG_INVERT_Y);
    texture[1] = SOIL_load_OGL_texture ( "C:\\EscorpiaoCostas.png",
        SOIL_LOAD_RGBA, SOIL_CREATE_NEW_ID,SOIL_FLAG_INVERT_Y);
    texture[2] = SOIL_load_OGL_texture ( "C:\\escorpiaoFofo.png",
        SOIL_LOAD_RGBA, SOIL_CREATE_NEW_ID,SOIL_FLAG_INVERT_Y);
    if(texture[0] == 0||texture[1] == 0||texture[2] == 0){
        return false;
    }
    // Typical Texture Generation Using Data From The Bitmap
    glBindTexture(GL_TEXTURE_2D, texture[0]);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);

	glEnable(GL_TEXTURE_2D);			    // Enable Texture Mapping ( NEW )
	glShadeModel(GL_SMOOTH);			    // Enable Smooth Shading
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClearDepth(1.0f);						// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);				// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);					// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

    return true; // Return Success
}


void display();

class Osso
{
public:
    Osso(float a, float l): largura(l), altura(a), conexcao(0) {}
    void desenha();

    void setConexcao(Osso *osso, float ang) {conexcao = osso, angulo = ang;}

    void setAngulo(float ang){angulo = ang;}
    float getAngulo(){return angulo;}

protected:
    float largura;
    float altura;

    float angulo;
    Osso *conexcao;
};

void Osso::desenha()
{
    glPushMatrix();  //salva o contexto(1)

      glTranslatef (0.0, altura/1.5, 0.0); //vai para o meio do osso

      glPushMatrix();   //salva o contexto(2)
        glScalef (largura, altura, largura);  //escala para o tamanho do osso

        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture[0]);
        cubo(largura); //desenha o osso
        glDisable(GL_TEXTURE_2D);

      glPopMatrix();    //restaura o contexto(2)

      glTranslatef (0.0, altura/2.0, 0.0); // vai para a ponta do osso

      glutSolidSphere(0.45*largura,8,8);        //desenha a bolinha

      if (conexcao)
      {
          glRotatef(30, 1.0, 0.0, 0.0); //rotaciona para o angulo da conexcao (o novo angulo após a formação de uma parte da pata)
          conexcao->desenha();              //desenha recursivamente
      }

    glPopMatrix();  //restaura o contexto(1)
};
////////////////////////////////////////////////////////////
class Pata // vai se tronar uma pata
{
public:
    Pata(float comprimento, float largura);
    void desenha() {a.desenha();}
    void setCurvatura(float curvatura);
    float getCurvatura() {return a.getAngulo()*100/90;}

protected:
    Osso a,b,c;
};

Pata::Pata(float comprimento, float largura)
  : a(comprimento*0.4,largura), b(comprimento*0.35,largura), c(comprimento*0.25,largura * 0.8)  //Respectivamente: a - primeira parte, b - segunda parte, c - terceira parte da perna
{
    a.setConexcao(&b,0.0);
    b.setConexcao(&c,0.0);
}

void Pata::setCurvatura(float curvatura)
{
    a.setAngulo(curvatura*0.9);
    b.setAngulo(curvatura*0.9);
}
////////////////////////////////////////////////////////////
class Ferrao // vai se tronar o ferrão ou garras
{
public:
    Ferrao(float comprimento, float largura);
    void desenha() {a.desenha();}
    void setCurvatura(float curvatura);
    float getCurvatura() {return a.getAngulo()*100/90;}

protected:
    Osso a, b, c, d, e, f;
};

Ferrao::Ferrao(float comprimento, float largura)
  : a(comprimento*0.5,largura), b(comprimento*0.5,largura), c(comprimento*0.5,largura), d(comprimento*0.5,largura), e(comprimento*0.5,largura), f(comprimento*0.5,largura * 0.7)
{
    a.setConexcao(&b,0.0);
    b.setConexcao(&c,0.0);
    c.setConexcao(&d,0.0);
    d.setConexcao(&e,0.0);
    e.setConexcao(&f,0.0);
}

void Ferrao::setCurvatura(float curvatura)
{
    a.setAngulo(curvatura*0.9);
    b.setAngulo(curvatura*0.9);
    c.setAngulo(curvatura*0.9);
    d.setAngulo(curvatura*0.9);
    e.setAngulo(curvatura*0.9);
    f.setAngulo(curvatura*0.9);

}
////////////////////////////////////////////////////

class Garra
{
public:
    Garra(float comprimento, float largura);
    void desenha() {a.desenha();}
    void setCurvatura(float curvatura);
    float getCurvatura() {return a.getAngulo()*100/90;}

protected:
    Osso a,b,c;
};

Garra::Garra(float comprimento, float largura)
  : a(comprimento*0.8,largura), b(comprimento*0.8,largura), c(comprimento*0.5,largura * 0.9)
{
    a.setConexcao(&b,0.0);
    a.setConexcao(&c,1.0);
}

void Garra::setCurvatura(float curvatura)
{
    a.setAngulo(curvatura*0.9);
    b.setAngulo(curvatura*0.9);
}





class Escorpiao
{
public:
    Escorpiao(float grossura);
    void desenha();
    void setCurvatura(int pata,float curv);
    float getCurvatura(int pata) {return curvatura[pata];}
    void abrir(bool tudoJunto = false);
    void fechar(bool tudoJunto = false);
    void tchau();
    void cisne();
    void hangloose();
    void dedoDuro();
    void positivo();
    void girar();
    void andar();
    void normal();
    void home();
protected:
    float grossura;

    Pata perna1;
    Pata perna2;
    Pata perna3;
    Pata perna4;

    Pata perna5;
    Pata perna6;
    Pata perna7;
    Pata perna8;


    Ferrao ferrao;

    Garra garraEsq;
    Garra garraDir;

    float curvatura[10];
};

Escorpiao::Escorpiao(float gros)
  : grossura(gros),
    perna1(6*grossura,grossura), //tamanho da pata mindinho
    perna2(6*grossura,grossura), //tamanho da pata anelar
    perna3(6*grossura,grossura), //tamanho da pata maior
    perna4(6*grossura,grossura), //tamanho da pata indicador

    perna5(6*grossura,grossura), //tamanho da pata
    perna6(6*grossura,grossura), //tamanho da pata
    perna7(6*grossura,grossura), //tamanho da pata
    perna8(6*grossura,grossura), //tamanho da pata

    ferrao(4*grossura,grossura), //tamanho do ferrão

    garraEsq(4*grossura,grossura),
    garraDir(4*grossura,grossura)
{
    for (int i=0;i<4;i++) {
        curvatura[i] = 90;
    } //Curvatura inicial do escorpião

    for (int i=4;i<9;i++) {
        curvatura[i] = -90;
    }

    curvatura[9] = 0;
}

void Escorpiao::desenha()
{
    glPushMatrix();

      glTranslatef(0.0,6.0*grossura,0.0);
      glPushMatrix();
        glTranslatef(-5*grossura,-2.5*grossura,3*grossura);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[0]*0.9,1.0,0.0,0.0);
        perna1.desenha();
      glPopMatrix();

      glPushMatrix();
        glTranslatef(-2.5*grossura,-2.5*grossura,3*grossura);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[1]*0.9,1.0,0.0,0.0);
        perna2.desenha();
      glPopMatrix();

      glPushMatrix();
        glTranslatef(0.0,-2.5*grossura,3*grossura);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[2]*0.9,1.0,0.0,0.0);
        perna3.desenha();
      glPopMatrix();

      glPushMatrix();
        glTranslatef(2.5*grossura,-2.5*grossura,3*grossura);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[3]*0.9,60.0,0.0,0.0);
        perna4.desenha();
      glPopMatrix();

    // pernas do outro lado
      glPushMatrix();
        glTranslatef(-5*grossura,-2.5*grossura,-3*grossura);
        glRotatef(180.0, 0.0, 1.0, 0.0);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[4]*0.9,-1.0,0.0,0.0);
        perna5.desenha();
      glPopMatrix();

      glPushMatrix();
        glTranslatef(-2.5*grossura,-2.5*grossura,-3*grossura);
        glRotatef(180.0, 0.0, 1.0, 0.0);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[5]*0.9,-1.0,0.0,0.0);
        perna6.desenha();
      glPopMatrix();

      glPushMatrix();
        glTranslatef(0.0,-2.5*grossura,-3*grossura);
        glRotatef(180.0, 0.0, 1.0, 0.0);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[6]*0.9,-1.0,0.0,0.0);
        perna7.desenha();
      glPopMatrix();

      glPushMatrix();
        glTranslatef(2.5*grossura,-2.5*grossura,-3*grossura);
        glRotatef(180.0, 0.0, 1.0, 0.0);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[7]*0.9,-1.0,0.0,0.0);
        perna8.desenha();
      glPopMatrix();

      //Ferrao

      glPushMatrix();
        glTranslatef(5*grossura,-2*grossura,0*grossura);
        glRotatef(-90, 0.0, 1.0, 0.0);
        glRotatef(-50.0, 1.0, 0.0, 0.0);
        glRotatef(curvatura[9],1.0,0.0,0.0);
        glScalef(1.5, 1, 1);
        glutSolidSphere(grossura,8,8);
        ferrao.desenha();
      glPopMatrix();

      //Garras

      glPushMatrix();
        glTranslatef(-5.5*grossura,-3*grossura,-3*grossura);
        glRotatef(90.0, 0.0, -1.0, 0.0);
        glRotatef(90.0, 0.0, 0.0, 1.0);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[8]*0.9,-1.0,0.0,0.0);
        garraEsq.desenha();
      glPopMatrix();


      glPushMatrix();
        glTranslatef(-5.5*grossura,-3*grossura,3*grossura);
        glRotatef(90.0, 0.0, -1.0, 0.0);
        glRotatef(90.0, 0.0, 0.0, -1.0);
        glutSolidSphere(grossura,8,8);
        glRotatef(curvatura[8]*0.9,-1.0,0.0,0.0);
        garraDir.desenha();
      glPopMatrix();

    glPopMatrix(); //apendices

    glPushMatrix(); // Base do corpo (cefalotórax)
        glTranslatef(-0.75*grossura,3.0*grossura,0.0);
        glScalef(10*grossura,1.5*grossura,5.0*grossura); //o comprimento das dimensões

        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture[1]);
        cubo(1.0);    //desenha o osso
        glDisable(GL_TEXTURE_2D);



    glPopMatrix();

    glPushMatrix(); // cabeça do corpo
        glTranslatef(-2.75*grossura,3.0*grossura,0.0);
        glScalef(12*grossura,1*grossura,3.0*grossura); //o comprimento das dimensões
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture[2]);
        cubo(1.0);    //desenha o osso
        glDisable(GL_TEXTURE_2D);
    glPopMatrix();
}

Escorpiao m(1.0);

void Escorpiao::setCurvatura(int perna,float curv)
{
    curvatura[perna] = curv;

    switch(perna)
    {
        case 0: perna1.setCurvatura(curv); break;
        case 1: perna2.setCurvatura(curv); break;
        case 2: perna3.setCurvatura(curv); break;
        case 3: perna4.setCurvatura(curv); break;

        case 4: perna5.setCurvatura(curv); break;
        case 5: perna6.setCurvatura(curv); break;
        case 6: perna7.setCurvatura(curv); break;
        case 7: perna8.setCurvatura(curv); break;

        case 9: ferrao.setCurvatura(curv); break;

    }
}

void Escorpiao::abrir(bool tudoJunto)
{
    if (tudoJunto)
        for (int j=getCurvatura(1);j>=0;j-=5)
        {
            for (int i=4;i>=0;i--)
            {
                setCurvatura(i,j);

            }
            display();
        }
    else
        for (int i=4;i>=0;i--)
        {
            for (int j=getCurvatura(i);j>=0;j-=5)
            {
                setCurvatura(i,j);
                display();
            }
        }

}

void Escorpiao::fechar(bool tudoJunto)
{
    if (tudoJunto)
    for (int j=getCurvatura(1);j<=100;j+=5)
    {
        for (int i=0;i<5;i++)
        {
            setCurvatura(i,j);
        }
        display();
    }
    else
    for (int i=0;i<5;i++)
    {
        for (int j=getCurvatura(i);j<=100;j+=5)
        {
            setCurvatura(i,j);
            display();
        }
    }
}

void Escorpiao::tchau()
{
    for(int i = 0 ; i < 180; i+=5)
    {
         if (m.getCurvatura(8) > -110) {
            m.setCurvatura(8,m.getCurvatura(8)-5);
         }

         display();
         usleep(100);

    }

    for(int i = 0 ; i < 180; i+=20)
    {
         if (m.getCurvatura(9) < 60) {
            m.setCurvatura(9,m.getCurvatura(9)+8);
         }
    display();
    usleep(1000);



    }

}

void Escorpiao::cisne()
{

    for(int i = 0 ; i < 180; i+=10)
    {
        if (m.getCurvatura(0) > 0) {
            m.setCurvatura(0,m.getCurvatura(0)-5);
        }


        if (m.getCurvatura(4) < 0) {
            m.setCurvatura(4,m.getCurvatura(4)+5);
        }
        display();
        usleep(1000);
    }

    for(int i = 0 ; i < 180; i+=15)
    {
        if (m.getCurvatura(1) > 0) {
            m.setCurvatura(1,m.getCurvatura(1)-5);
        }


        if (m.getCurvatura(5) < 0) {
            m.setCurvatura(5,m.getCurvatura(5)+5);
        }
        display();
        usleep(1000);
    }

    for(int i = 0 ; i < 180; i+=30)
    {
        if (m.getCurvatura(2) > 0) {
            m.setCurvatura(2,m.getCurvatura(2)-5);
        }

        if (m.getCurvatura(6) < 0) {
            m.setCurvatura(6,m.getCurvatura(6)+5);
        }
        display();
        usleep(1000);
    }

    for(int i = 0 ; i < 180; i+=45)
    {
        if (m.getCurvatura(3) > 0) {
            m.setCurvatura(3,m.getCurvatura(3)-5);
        }

        if (m.getCurvatura(7) < 0) {
            m.setCurvatura(7,m.getCurvatura(7)+5);
        }
        display();
        usleep(1000);
    }

    for(int i = 0 ; i < 180; i+=30)
    {
         if (m.getCurvatura(9) < 50) {
            m.setCurvatura(9,m.getCurvatura(9)+6);
         }

        display();
        usleep(1000);
    }



}

void Escorpiao::hangloose()
{
    fechar(true);
    for (int j=getCurvatura(2);j>=0;j-=20)
    {
        setCurvatura(0,j);
        setCurvatura(4,j);
        ang3 += 3;
        display();
    }
    for(int j = 0 ;j < 3 ; j++)
    {
        ang += 5;
        display();
    }
    for(int i = 0; i< 3; i++)
    {
        for(int j = 0 ;j < 6 ; j++)
        {
            ang -= 5;
            display();
        }
        for(int j = 0 ;j < 6 ; j++)
        {
            ang += 5;
            display();
        }
    }
    for(int j = 0 ;j < 3 ; j++)
    {
        ang -= 5;
        display();
    }
    for(int j = 0 ;j < 6 ; j++)
    {
        ang3 -= 3;
        display();
    }
}

void Escorpiao::girar()
{

    for(int i = 0 ; i < 180; i+=90)
    {
        ang += 22.5;
        //ang2 += 20;
        //ang3 += 20;
        display();
    }

}

void Escorpiao::andar()
{
    // Define a amplitude da curvatura
    float amplitude = 10.0;
    int steps = 3;
    int ciclos = 1;

    for (int i = 0; i < ciclos; i++) {
        // Movimenta as pernas em sequência
        for (int step = 0; step < steps; ++step) {
            ///////////////////////////
            if (m.getCurvatura(8) > 0) {
                m.setCurvatura(8, m.getCurvatura(8) - amplitude);
            }
            display();
            usleep(5000);
            ///////////////////////////

            // Movimento das pernas 1 e 5
            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(0) > 0) {
                    m.setCurvatura(0, m.getCurvatura(0) - amplitude);
                }
                if (m.getCurvatura(4) < 0) {
                    m.setCurvatura(4, m.getCurvatura(4) + amplitude);
                }
                display();
                usleep(50000);
            }

            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(0) > 0) {
                    m.setCurvatura(0, m.getCurvatura(0) + amplitude);
                }
                if (m.getCurvatura(4) < 0) {
                    m.setCurvatura(4, m.getCurvatura(4) - amplitude);
                }
                display();
                usleep(50000);
            }

            // Movimento das pernas 2 e 6
            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(1) > 0) {
                    m.setCurvatura(1, m.getCurvatura(1) - amplitude);
                }
                if (m.getCurvatura(5) < 0) {
                    m.setCurvatura(5, m.getCurvatura(5) + amplitude);
                }
                display();
                usleep(50000);
            }

            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(1) > 0) {
                    m.setCurvatura(1, m.getCurvatura(1) + amplitude);
                }
                if (m.getCurvatura(5) < 0) {
                    m.setCurvatura(5, m.getCurvatura(5) - amplitude);
                }
                display();
                usleep(50000);
            }

            // Movimento das pernas 3 e 7
            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(2) > 0) {
                    m.setCurvatura(2, m.getCurvatura(2) - amplitude);
                }
                if (m.getCurvatura(6) < 0) {
                    m.setCurvatura(6, m.getCurvatura(6) + amplitude);
                }
                display();
                usleep(50000);
            }

            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(2) > 0) {
                    m.setCurvatura(2, m.getCurvatura(2) + amplitude);
                }
                if (m.getCurvatura(6) < 0) {
                    m.setCurvatura(6, m.getCurvatura(6) - amplitude);
                }
                display();
                usleep(50000);
            }

            // Movimento das pernas 4 e 8
            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(3) > 0) {
                    m.setCurvatura(3, m.getCurvatura(3) - amplitude);
                }
                if (m.getCurvatura(7) < 0) {
                    m.setCurvatura(7, m.getCurvatura(7) + amplitude);
                }
                display();
                usleep(50000);
            }

            for (int j = 0; j < 180; j += 90) {
                if (m.getCurvatura(3) > 0) {
                    m.setCurvatura(3, m.getCurvatura(3) + amplitude);
                }
                if (m.getCurvatura(7) < 0) {
                    m.setCurvatura(7, m.getCurvatura(7) - amplitude);
                }
                display();
                usleep(50000);
            }
        }
    }
}

void Escorpiao::normal() {

    for (int i = 0; i < 4; ++i) {
        curvatura[i] = 90;
    }

    for (int i = 4; i < 9; ++i) {
        curvatura[i] = -90;
    }

    curvatura[9] = 0;

}


void Escorpiao::home()
{
    abrir(true);

    if (ang < 0)
        ang += 360;
    if (ang2< 0)
        ang2+= 360;
    if (ang3< 0)
        ang3+= 360;


    while (ang > 0)
    {
        ang-= 10;
        display();
    }
    ang = 0;
    while (ang2 > 0)
    {
        ang2-= 10;
        display();
    }
    ang2 = 0;
    while (ang3 > 0)
    {
        ang3-= 10;
        display();
    }
    ang3 = 0;
    display();

}



/////////////////////////////////////////////////////////////

///////////////////////////////////////////////////
void init(void)
{
//    LoadGLTextures();
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glClearDepth(1.0);				// Enables Clearing Of The Depth Buffer
    glDepthFunc(GL_LEQUAL);				// The Type Of Depth Test To Do
    glEnable(GL_DEPTH_TEST);			// Enables Depth Testing
    glShadeModel(GL_SMOOTH);			// Enables Smooth Color Shading
}

void display(void)
{
   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
//   glBindTexture(GL_TEXTURE_2D, texture[0]);
   //////////////ISSO AQUI EH PRA LUZ///////////E EU AINDA N SEI COMO FUNCA/////
    GLfloat			diffuseLight[] = { 1.0f, 1.0f, 1.0f, 1.0};
    GLfloat			ambientLight[] = { 0.2f, 0.2f, 0.4f, 1.0};
    GLfloat			lightPos[] = { 0.0f, 500.0f, 100.0f, 1.0f };
    glEnable(GL_LIGHTING);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
    glLightfv(GL_LIGHT0, GL_SPECULAR, diffuseLight);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glColor3f(1.0f,1.0f,1.0f);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, diffuseLight );
    glMateriali(GL_FRONT_AND_BACK, GL_SHININESS, 50);
    //////////////////////////////////////////////////////////////////////////

    glPushMatrix();

      glTranslatef (0.0, -5.0, -15.0);
      glRotatef (ang3, 0.0, 0.0, 1.0);
      glRotatef (ang, 0.0, 1.0, 0.0);
      glRotatef (ang2, 1.0, 0.0, 0.0);
      glColor3f(1.0,0.8,0);

      m.desenha();

    glPopMatrix();

    glutSwapBuffers();
}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   gluPerspective(55.0, (GLfloat) w/(GLfloat) h, 1.0, 40.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glTranslatef (0.0, 0.0, -10.0);
}


void idle()
{
}

void keyboard (unsigned char key, int x, int y)
{
    switch(key)
    {
        case 'q':
            if (m.getCurvatura(0) < 100)
                m.setCurvatura(0,m.getCurvatura(0)+5);
            break;
        case 'a':
            if (m.getCurvatura(0) > 0)
                m.setCurvatura(0,m.getCurvatura(0)-5);
            break;
        case 'w':
            if (m.getCurvatura(1) < 100)
                m.setCurvatura(1,m.getCurvatura(1)+5);
            break;
        case 's':
            if (m.getCurvatura(1) > 0)
                m.setCurvatura(1,m.getCurvatura(1)-5);
            break;
         case 'e':
            if (m.getCurvatura(2) < 100)
                m.setCurvatura(2,m.getCurvatura(2)+5);
            break;
        case 'd':
            if (m.getCurvatura(2) > 0)
                m.setCurvatura(2,m.getCurvatura(2)-5);
            break;
        case 'r':
            if (m.getCurvatura(3) < 100)
                m.setCurvatura(3,m.getCurvatura(3)+5);
            break;

         case 'y':
            if (m.getCurvatura(4) > -100)
                m.setCurvatura(4,m.getCurvatura(4)-5);
            break;

         case 'u':
            if (m.getCurvatura(5) > -100)
                m.setCurvatura(5,m.getCurvatura(5)-5);
            break;

         case 'i':
            if (m.getCurvatura(6) > -100)
                m.setCurvatura(6,m.getCurvatura(6)-5);
            break;

         case 'o':
            if (m.getCurvatura(7) > -100)
                m.setCurvatura(7,m.getCurvatura(7)-5);
            break;

         case 'h':
            if (m.getCurvatura(4) < 0)
                m.setCurvatura(4,m.getCurvatura(4)+5);
            break;

         case 'j':
            if (m.getCurvatura(5) < 0)
                m.setCurvatura(5,m.getCurvatura(5)+5);
            break;

         case 'k':
            if (m.getCurvatura(6) < 0)
                m.setCurvatura(6,m.getCurvatura(6)+5);
            break;

         case 'l':
            if (m.getCurvatura(7) < 0)
                m.setCurvatura(7,m.getCurvatura(7)+5);
            break;


         case 't':
            if (m.getCurvatura(9) > -60)
                m.setCurvatura(9,m.getCurvatura(9)-5); //ferrao
            break;

         case 'g':
            if (m.getCurvatura(9) < 110)
                m.setCurvatura(9,m.getCurvatura(9)+5); //ferrao
            break;

         case 'z':
            if (m.getCurvatura(8) > -110)
                m.setCurvatura(8,m.getCurvatura(8)-5);
            break;

         case 'x':
            if (m.getCurvatura(8) < 0)
                m.setCurvatura(8,m.getCurvatura(8)+5);
            break;


        case 'f':
            if (m.getCurvatura(3) > 0)
                m.setCurvatura(3,m.getCurvatura(3)-5);
            break;

        case '.': //>
            ang += 5;
            if (ang>360)
                ang -= 360;
            break;
        case ',': //<
            ang -= 5;
            if (ang<0)
                ang += 360;
            break;
        case ']':
            ang2 += 5;
            if (ang2>360)
                ang2 -= 360;
            break;
        case '[':
            ang2 -= 5;
            if (ang2<0)
                ang2 += 360;
            break;
        case '+':
            m.abrir();
            break;
        case '*' :
            m.abrir(true);
            break;
        case '/' :
            m.fechar(true);
            break;
        case '-':
            m.fechar();
            break;
        case 27: //ESC
            exit(0);
            break;
        case '9':
            ang3 += 5;
            if (ang3>360)
                ang3 -= 360;
            break;
        case '0':
            ang3 -= 5;
            if (ang3<0)
                ang3 += 360;
            break;
        case '1' :
            m.tchau();
            break;
        case '2' :
            m.cisne();
            break;
        case '3' :
            m.hangloose();
            break;
        case '4' :
            m.girar();
            break;
        case '5':
            m.andar();
            break;
        case '6':
            m.normal();
            break;
        case 8 :
            m.home();
            break;

        default:
            return;
    }
    glutPostRedisplay();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize (300, 300);
    glutInitWindowPosition (200, 200);
    glutCreateWindow (argv[0]);
    init ();
    LoadGLTextures();
    printf("FullScreen?(y/n) ");
    if (getchar() == 'y')
        glutFullScreen();

    glutIdleFunc(idle);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
